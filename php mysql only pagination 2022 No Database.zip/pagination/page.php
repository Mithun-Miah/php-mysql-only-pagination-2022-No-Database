<?php
$connect = mysqli_connect('localhost','root','','pagination');
if($connect){
    //echo("<script>alert('Connection Success')</script>");
}else{
    echo("<script>alert('Connection Failed')</script>");
}

if(isset($_POST['add_book'])){
    $b_id = $_POST['book_id'];
    $b_title = $_POST['book_title'];
    $auth_name = $_POST['author_name'];
    $pub_name = $_POST['publisher_name'];
    $b_location = $_POST['book_location'];

    $query = "insert into input(book_id,book_title,author_name,publisher_name,book_location)
             values('$b_id','$b_title','$auth_name','$pub_name','$b_location')";
    
    $query_run = mysqli_query($connect,$query);

    if($query_run){
        echo "<script>alert('data send Success')</script>";
    } else{
        echo "<script>alert('Data send Fail')</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pagination</title>

    <style>
        .container{
            width: 90vw;
            height: auto;
            border: 1px solid red;
            padding: 10px;
            margin: auto;
        }
        form h3{
            text-align: center;
            text-transform: uppercase;
        }
        label {width: 100px;}
        input[type="text"] {
            width: 310px;
            height: 20px;
            padding: 5px;
        }
        form {
            width: 100%;
            background-color: aliceblue;
            padding: 10px;
        }
        button {
            padding: 10px;
            border: none;
            background-color: thistle;
            border-radius: 10px;
            box-shadow: 1px 1px 2px black;
            cursor: pointer;
            width: 200px;
            transition: 1s ease-in;
        }
        button:hover{
            background-color: brown;
            color: white;
        }
        .title2{
            text-align:center;
        }
        table,tr,th,td{
            border: 1px solid black;
            border-collapse: collapse;
            padding: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <form action="" method="post">
            <h3>Page Pagination</h3>
            <label for="">Book ID</label>
            <input type="text" name="book_id">
            <br><br>
            <label for="">Book Title</label>
            <input type="text" name="book_title">
            <br><br>
            <label for="">Author Name</label>
            <input type="text" name="author_name">
            <br><br>
            <label for="">Publisher Name</label>
            <input type="text" name="publisher_name">
            <br><br>
            <label for="">Book Location</label>
            <input type="text" name="book_location">
            <br><br>
            <button name="add_book">Add Book</button>
        </form>

        <div class="data_show">
            <h2 class="title2">Show Data</h2>

<?php
// Dynamic Page pagination

// variable to store number of rows per page
$limit = 5;  
// query to retrieve all rows from the table Countries
$getQuery = "select * from input";    
// get the result
$result = mysqli_query($connect, $getQuery);  
$total_rows = mysqli_num_rows($result);
// get the required number of pages
$total_pages = ceil ($total_rows / $limit);    
// update the active page number
if (!isset ($_GET['page']) ) {  
    $page_number = 1;  
} else {  
    $page_number = $_GET['page'];  
}
// get the initial page number
$initial_page = ($page_number-1) * $limit;   

// get data of selected rows per page    
$getQuery = "SELECT * FROM input LIMIT " . $initial_page . ',' . $limit;  

$result = mysqli_query($connect, $getQuery);?>
<table>
                <tr>
                        <th>Book ID</th>
                        <th>SL. No.</th>
                        <th>Book Title</th>
                        <th>Author Name</th>
                        <th>Publisher Name</th>
                        <th>Book Location</th>
                        <th>Action</th>
                    </tr>

<?php

//display the retrieved result on the webpage  
while ($row = mysqli_fetch_array($result)) {  ?>

                <tr>
                        <td><?php echo $row["sl_no"];?></td>
                        <td><?php echo $row["book_id"];?></td>
                        <td><?php echo $row["book_title"];?></td>
                        <td><?php echo $row["author_name"];?></td>
                        <td><?php echo $row["publisher_name"];?></td>
                        <td><?php echo $row["book_location"];?></td>
                    </tr>
                
                   
                <?php
                    }
                ?>
                </table>  
                <br>
                <a href="pagination.php?pageno=1"> < </a> 
<?php
// show page number with link   
for($page_number = 1; $page_number<= $total_pages; $page_number++) {  
    echo '<a href = "page.php?page=' . $page_number . '" style="background-color:blue;color:white;padding:6px; margin:2px;border-radius:5px;">' . $page_number . ' </a>';
}

?>
                <a href="pagination.php?pageno=2"> > </a>
        </div>
    </div>
    
</body>
</html>